import numpy as np
from flask import Flask, request, jsonify, render_template
import spacy

app = Flask(__name__)
nlp = spacy.load('C:/Users/Ale/Desktop/jupyter_folder/prototype.model')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    float_features = [str(x) for x in request.form.values()]
    doc = nlp(float_features[0])

    results = {}

    elements = [(X.text, X.label_) for X in doc.ents]
    poi_elements = [x for x in elements if x[1] == 'POI']
    srt_elements = [x for x in elements if x[1] == 'SRT']

    if not poi_elements:
        poi_elements = [('', '')]

    if not srt_elements:
        srt_elements = [('', '')]

    results[id] = (poi_elements, srt_elements)


    return render_template("index.html", poi = "Point of Interest: " + results[id][0][0][0],
                           srt = "Street: " + results[id][1][0][0])


@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = nlp([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)